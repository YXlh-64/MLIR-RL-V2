# Generated V5 schedules

Planned choices are followed by actual application outcomes. Pointer decisions remain in schedule.json. Inspect result.json for failures/timeouts.

<details>
<summary>ops_and_blocks/albert_block_147.mlir</summary>

- operation_4: I(0,1,2)
- operation_4: TPF(operation_3;0,4,32)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2)
- operation_3_operation_4: T(0,0,8)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2)
- operation_2: TPF(operation_1;0,4,32)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: T(0,0,8,0)
- operation_1_operation_2: T(0,0,1,0)
- operation_1_operation_2: NT()
- operation_0: I(0,1,2)
- operation_0: T(0,0,8)
- operation_0: V(True)

- Applied: operation_4: I(0,1,2) — applied
- Applied: operation_4: TPF(operation_3;0,4,32) — applied
- Applied: operation_4: V(False) — fallback
- Applied: operation_3_operation_4: I(0,1,2) — applied
- Applied: operation_3_operation_4: T(0,0,8) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2) — applied
- Applied: operation_2: TPF(operation_1;0,4,32) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2,3) — applied
- Applied: operation_1_operation_2: T(0,0,8,0) — applied
- Applied: operation_1_operation_2: T(0,0,1,0) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,1,2) — applied
- Applied: operation_0: T(0,0,8) — applied
- Applied: operation_0: V(True) — applied

[Raw decisions](artifacts/ops_and_blocks/albert_block_147/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/albert_block_147/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/albert_block_147/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/albert_block_147/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/albert_block_147/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/albert_block_147/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/albert_block_422.mlir</summary>

- operation_4: I(0,1,2)
- operation_4: TPF(operation_3;0,4,32)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2)
- operation_2: TPF(operation_1;0,4,32)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: T(0,0,8,0)
- operation_1_operation_2: T(0,0,1,0)
- operation_1_operation_2: NT()
- operation_0: I(0,1,2)
- operation_0: T(0,0,8)
- operation_0: T(0,0,1)
- operation_0: NT()

- Applied: operation_4: I(0,1,2) — applied
- Applied: operation_4: TPF(operation_3;0,4,32) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,1,2) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2) — applied
- Applied: operation_2: TPF(operation_1;0,4,32) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2,3) — applied
- Applied: operation_1_operation_2: T(0,0,8,0) — applied
- Applied: operation_1_operation_2: T(0,0,1,0) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,1,2) — applied
- Applied: operation_0: T(0,0,8) — applied
- Applied: operation_0: T(0,0,1) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/albert_block_422/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/albert_block_422/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/albert_block_422/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/albert_block_422/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/albert_block_422/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/albert_block_422/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/albert_block_488.mlir</summary>

- operation_4: I(0,1,2)
- operation_4: TPF(operation_3;0,4,32)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,4,32,32)
- operation_2: T(0,0,8,0)
- operation_2: NT()
- operation_1_operation_2: I(0,1,2)
- operation_1_operation_2: T(0,0,8)
- operation_1_operation_2: T(0,0,1)
- operation_1_operation_2: NT()
- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2) — applied
- Applied: operation_4: TPF(operation_3;0,4,32) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,1,2) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,4,32,32) — applied
- Applied: operation_2: T(0,0,8,0) — applied
- Applied: operation_2: NT() — applied
- Applied: operation_1_operation_2: I(0,1,2) — applied
- Applied: operation_1_operation_2: T(0,0,8) — applied
- Applied: operation_1_operation_2: T(0,0,1) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/albert_block_488/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/albert_block_488/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/albert_block_488/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/albert_block_488/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/albert_block_488/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/albert_block_488/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/albert_block_68.mlir</summary>

- operation_4: I(0,1,2)
- operation_4: TPF(operation_3;0,4,32)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,4,32,32)
- operation_2: T(0,0,8,0)
- operation_2: NT()
- operation_1_operation_2: I(0,1,2)
- operation_1_operation_2: T(0,0,8)
- operation_1_operation_2: T(0,0,1)
- operation_1_operation_2: NT()
- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2) — applied
- Applied: operation_4: TPF(operation_3;0,4,32) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,1,2) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,4,32,32) — applied
- Applied: operation_2: T(0,0,8,0) — applied
- Applied: operation_2: NT() — applied
- Applied: operation_1_operation_2: I(0,1,2) — applied
- Applied: operation_1_operation_2: T(0,0,8) — applied
- Applied: operation_1_operation_2: T(0,0,1) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/albert_block_68/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/albert_block_68/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/albert_block_68/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/albert_block_68/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/albert_block_68/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/albert_block_68/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/convnext_tiny_block_370.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,16,0,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,5,1,4,3,2)
- operation_3_operation_4: T(0,0,8,0,0,0)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,1,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: V(True)
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,16,0,0) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,5,1,4,3,2) — applied
- Applied: operation_3_operation_4: T(0,0,8,0,0,0) — applied
- Applied: operation_3_operation_4: V(False) — fallback
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,1,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2,3) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/convnext_tiny_block_370/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/convnext_tiny_block_370/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/convnext_tiny_block_370/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/convnext_tiny_block_370/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/convnext_tiny_block_370/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/convnext_tiny_block_370/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/convnext_tiny_block_377.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,0,0,32)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,0,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,5,1,4,3,2)
- operation_1_operation_2: T(0,0,8,0,0,0)
- operation_1_operation_2: V(True)
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,0,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,0,0,32) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,1,2,3) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,0,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,5,1,4,3,2) — applied
- Applied: operation_1_operation_2: T(0,0,8,0,0,0) — applied
- Applied: operation_1_operation_2: V(False) — fallback
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/convnext_tiny_block_377/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/convnext_tiny_block_377/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/convnext_tiny_block_377/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/convnext_tiny_block_377/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/convnext_tiny_block_377/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/convnext_tiny_block_377/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/efficientnet_b0_block_163.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,4,4,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,5,6,4,3,2,1)
- operation_3_operation_4: T(0,0,0,0,4,1,0)
- operation_3_operation_4: T(0,0,0,0,2,0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,4,0)
- operation_2: T(0,0,1,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: T(0,0,1,0)
- operation_1_operation_2: V(True)
- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(0,1,2,1,2,4)
- operation_0: V(True)

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,4,4,0) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,5,6,4,3,2,1) — applied
- Applied: operation_3_operation_4: T(0,0,0,0,4,1,0) — applied
- Applied: operation_3_operation_4: T(0,0,0,0,2,0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,4,0) — applied
- Applied: operation_2: T(0,0,1,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2,3) — applied
- Applied: operation_1_operation_2: T(0,0,1,0) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(0,1,2,1,2,4) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/ops_and_blocks/efficientnet_b0_block_163/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/efficientnet_b0_block_163/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/efficientnet_b0_block_163/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/efficientnet_b0_block_163/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/efficientnet_b0_block_163/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/efficientnet_b0_block_163/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/efficientnet_b0_block_206.mlir</summary>

- operation_4: I(0,5,6,4,3,2,1)
- operation_4: TPF(operation_3;0,0,0,2,2,0,2)
- operation_4: V(True)
- operation_3_operation_4: I(0,5,6,4,3,2,1)
- operation_3_operation_4: T(0,0,0,0,0,1,0)
- operation_3_operation_4: T(0,0,0,0,0,0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,2,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: V(True)
- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(0,1,2,1,2,2)
- operation_0: V(True)

- Applied: operation_4: I(0,5,6,4,3,2,1) — applied
- Applied: operation_4: TPF(operation_3;0,0,0,2,2,0,2) — applied
- Applied: operation_4: V(False) — fallback
- Applied: operation_3_operation_4: I(0,5,6,4,3,2,1) — applied
- Applied: operation_3_operation_4: T(0,0,0,0,0,1,0) — applied
- Applied: operation_3_operation_4: T(0,0,0,0,0,0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,2,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2,3) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(0,1,2,1,2,2) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/ops_and_blocks/efficientnet_b0_block_206/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/efficientnet_b0_block_206/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/efficientnet_b0_block_206/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/efficientnet_b0_block_206/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/efficientnet_b0_block_206/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/efficientnet_b0_block_206/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/efficientnet_b0_block_388.mlir</summary>

- operation_4: I(0,5,6,4,3,2,1)
- operation_4: TPF(operation_3;0,0,0,2,0,0,2)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,4,0,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,5,6,4,3,2,1)
- operation_1_operation_2: T(0,0,0,32,0,0,0)
- operation_1_operation_2: V(True)
- operation_0: I(0,1,2,3)
- operation_0: V(True)

- Applied: operation_4: I(0,5,6,4,3,2,1) — applied
- Applied: operation_4: TPF(operation_3;0,0,0,2,0,0,2) — applied
- Applied: operation_4: V(False) — fallback
- Applied: operation_3_operation_4: I(0,1,2,3) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,4,0,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,5,6,4,3,2,1) — applied
- Applied: operation_1_operation_2: T(0,0,0,32,0,0,0) — applied
- Applied: operation_1_operation_2: V(False) — fallback
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: V(True) — applied

[Raw decisions](artifacts/ops_and_blocks/efficientnet_b0_block_388/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/efficientnet_b0_block_388/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/efficientnet_b0_block_388/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/efficientnet_b0_block_388/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/efficientnet_b0_block_388/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/efficientnet_b0_block_388/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/efficientnet_b0_block_408.mlir</summary>

- operation_4: I(0,5,6,4,3,2,1)
- operation_4: TPF(operation_3;0,0,0,2,2,0,2)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: T(0,0,1,0)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,2,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,5,6,4,3,2,1)
- operation_1_operation_2: T(0,0,0,32,2,1,0)
- operation_1_operation_2: T(0,0,0,0,0,0,0)
- operation_1_operation_2: NT()
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_4: I(0,5,6,4,3,2,1) — applied
- Applied: operation_4: TPF(operation_3;0,0,0,2,2,0,2) — applied
- Applied: operation_4: V(False) — fallback
- Applied: operation_3_operation_4: I(0,1,2,3) — applied
- Applied: operation_3_operation_4: T(0,0,1,0) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,2,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,5,6,4,3,2,1) — applied
- Applied: operation_1_operation_2: T(0,0,0,32,2,1,0) — applied
- Applied: operation_1_operation_2: T(0,0,0,0,0,0,0) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/efficientnet_b0_block_408/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/efficientnet_b0_block_408/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/efficientnet_b0_block_408/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/efficientnet_b0_block_408/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/efficientnet_b0_block_408/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/efficientnet_b0_block_408/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/efficientnet_b0_block_500.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,16,0,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: T(0,0,1,0)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,1,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: V(True)
- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(0,1,0,1,2,1)
- operation_0: V(True)

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,16,0,0) — failed

[Raw decisions](artifacts/ops_and_blocks/efficientnet_b0_block_500/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/efficientnet_b0_block_500/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/efficientnet_b0_block_500/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/efficientnet_b0_block_500/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/efficientnet_b0_block_500/methods/mlir_rl/schedule_ir_analysis.json) · [Schedule did not complete](artifacts/ops_and_blocks/efficientnet_b0_block_500/methods/mlir_rl/result.json)

</details>

<details>
<summary>ops_and_blocks/efficientnet_b0_block_564.mlir</summary>

- operation_4: I(0,5,6,4,3,2,1)
- operation_4: TPF(operation_3;0,0,0,32,1,0,2)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: T(0,0,1,0)
- operation_3_operation_4: T(0,0,0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,1,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: V(True)
- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(0,1,0,1,2,1)
- operation_0: V(True)

- Applied: operation_4: I(0,5,6,4,3,2,1) — applied
- Applied: operation_4: TPF(operation_3;0,0,0,32,1,0,2) — applied
- Applied: operation_4: V(False) — fallback
- Applied: operation_3_operation_4: I(0,1,2,3) — applied
- Applied: operation_3_operation_4: T(0,0,1,0) — applied
- Applied: operation_3_operation_4: T(0,0,0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,1,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2,3) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(0,1,0,1,2,1) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/ops_and_blocks/efficientnet_b0_block_564/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/efficientnet_b0_block_564/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/efficientnet_b0_block_564/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/efficientnet_b0_block_564/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/efficientnet_b0_block_564/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/efficientnet_b0_block_564/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/gat_block_7.mlir</summary>

- operation_4: I(0,1)
- operation_4: TPF(operation_3;0,16)
- operation_4: T(8,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,1,2)
- operation_3_operation_4: T(8,0,8)
- operation_3_operation_4: T(0,0,1)
- operation_3_operation_4: V(True)
- operation_2: I(0,1)
- operation_2: TPF(operation_1;0,16)
- operation_2: T(8,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1)
- operation_1_operation_2: T(8,0)
- operation_1_operation_2: V(True)
- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1) — applied
- Applied: operation_4: TPF(operation_3;0,16) — applied
- Applied: operation_4: T(8,0) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,1,2) — applied
- Applied: operation_3_operation_4: T(8,0,8) — applied
- Applied: operation_3_operation_4: T(0,0,1) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1) — applied
- Applied: operation_2: TPF(operation_1;0,16) — applied
- Applied: operation_2: T(8,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1) — applied
- Applied: operation_1_operation_2: T(8,0) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/gat_block_7/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/gat_block_7/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/gat_block_7/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/gat_block_7/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/gat_block_7/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/gat_block_7/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/gin_block_21.mlir</summary>

- operation_4: I(0,1)
- operation_4: TPF(operation_3;0,16)
- operation_4: T(8,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,1)
- operation_3_operation_4: T(8,0)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2)
- operation_2: TPF(operation_1;0,16,32)
- operation_2: T(8,0,8)
- operation_2: NT()
- operation_1_operation_2: I(0,1)
- operation_1_operation_2: T(8,0)
- operation_1_operation_2: T(0,0)
- operation_1_operation_2: NT()
- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1) — applied
- Applied: operation_4: TPF(operation_3;0,16) — applied
- Applied: operation_4: T(8,0) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,1) — applied
- Applied: operation_3_operation_4: T(8,0) — applied
- Applied: operation_3_operation_4: V(True) — applied
- Applied: operation_2: I(0,1,2) — applied
- Applied: operation_2: TPF(operation_1;0,16,32) — applied
- Applied: operation_2: T(8,0,8) — applied
- Applied: operation_2: NT() — applied
- Applied: operation_1_operation_2: I(0,1) — applied
- Applied: operation_1_operation_2: T(8,0) — applied
- Applied: operation_1_operation_2: T(0,0) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/gin_block_21/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/gin_block_21/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/gin_block_21/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/gin_block_21/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/gin_block_21/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/gin_block_21/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/gin_block_24.mlir</summary>

- operation_4: I(0,1,2)
- operation_4: TPF(operation_3;0,16,32)
- operation_4: T(8,0,8)
- operation_4: NT()
- operation_3_operation_4: I(0,1)
- operation_3_operation_4: T(8,0)
- operation_3_operation_4: T(0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,1)
- operation_2: TPF(operation_1;0,16)
- operation_2: T(8,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2)
- operation_1_operation_2: T(8,0,8)
- operation_1_operation_2: T(0,0,1)
- operation_1_operation_2: V(True)
- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2) — applied
- Applied: operation_4: TPF(operation_3;0,16,32) — applied
- Applied: operation_4: T(8,0,8) — applied
- Applied: operation_4: NT() — applied
- Applied: operation_3_operation_4: I(0,1) — applied
- Applied: operation_3_operation_4: T(8,0) — applied
- Applied: operation_3_operation_4: T(0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,1) — applied
- Applied: operation_2: TPF(operation_1;0,16) — applied
- Applied: operation_2: T(8,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2) — applied
- Applied: operation_1_operation_2: T(8,0,8) — applied
- Applied: operation_1_operation_2: T(0,0,1) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/gin_block_24/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/gin_block_24/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/gin_block_24/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/gin_block_24/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/gin_block_24/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/gin_block_24/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/mobilenet_v3_small_block_108.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,16,2,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,5,6,4,3,2,1)
- operation_3_operation_4: T(0,0,0,0,2,1,0)
- operation_3_operation_4: T(0,0,0,0,0,0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,4,2,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,5,6,4,3,2,1)
- operation_1_operation_2: T(0,0,0,32,2,1,0)
- operation_1_operation_2: V(True)
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,16,2,0) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,5,6,4,3,2,1) — applied
- Applied: operation_3_operation_4: T(0,0,0,0,2,1,0) — applied
- Applied: operation_3_operation_4: T(0,0,0,0,0,0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,4,2,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,5,6,4,3,2,1) — applied
- Applied: operation_1_operation_2: T(0,0,0,32,2,1,0) — applied
- Applied: operation_1_operation_2: V(False) — fallback
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/mobilenet_v3_small_block_108/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/mobilenet_v3_small_block_108/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/mobilenet_v3_small_block_108/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/mobilenet_v3_small_block_108/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/mobilenet_v3_small_block_108/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/mobilenet_v3_small_block_108/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/mobilenet_v3_small_block_394.mlir</summary>

- operation_4: I(0,1,2)
- operation_4: TPF(operation_3;0,4,32)
- operation_4: V(True)
- operation_3_operation_4: I(0,1)
- operation_3_operation_4: T(0,0)
- operation_3_operation_4: T(0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,1)
- operation_2: TPF(operation_1;0,16)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2)
- operation_1_operation_2: T(0,0,8)
- operation_1_operation_2: V(True)
- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2) — applied
- Applied: operation_4: TPF(operation_3;0,4,32) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,1) — applied
- Applied: operation_3_operation_4: T(0,0) — applied
- Applied: operation_3_operation_4: T(0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,1) — applied
- Applied: operation_2: TPF(operation_1;0,16) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2) — applied
- Applied: operation_1_operation_2: T(0,0,8) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/mobilenet_v3_small_block_394/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/mobilenet_v3_small_block_394/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/mobilenet_v3_small_block_394/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/mobilenet_v3_small_block_394/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/mobilenet_v3_small_block_394/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/mobilenet_v3_small_block_394/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/resnet50_block_3.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,16,4,0)
- operation_4: T(0,0,1,0)
- operation_4: NT()
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: T(0,0,1,0)
- operation_3_operation_4: T(0,0,0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,5,6,4,3,2,1)
- operation_2: TPF(operation_1;0,0,0,32,2,8,2)
- operation_2: T(0,0,0,0,0,1,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,5,1,4,3,2)
- operation_1_operation_2: T(0,0,8,0,0,1)
- operation_1_operation_2: V(True)
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,16,4,0) — applied
- Applied: operation_4: T(0,0,1,0) — applied
- Applied: operation_4: NT() — applied
- Applied: operation_3_operation_4: I(0,1,2,3) — applied
- Applied: operation_3_operation_4: T(0,0,1,0) — applied
- Applied: operation_3_operation_4: T(0,0,0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,5,6,4,3,2,1) — applied
- Applied: operation_2: TPF(operation_1;0,0,0,32,2,8,2) — applied
- Applied: operation_2: T(0,0,0,0,0,1,0) — applied
- Applied: operation_2: V(False) — fallback
- Applied: operation_1_operation_2: I(0,5,1,4,3,2) — applied
- Applied: operation_1_operation_2: T(0,0,8,0,0,1) — applied
- Applied: operation_1_operation_2: V(False) — fallback
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/resnet50_block_3/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/resnet50_block_3/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/resnet50_block_3/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/resnet50_block_3/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/resnet50_block_3/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/resnet50_block_3/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/resnet50_block_405.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,16,0,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,5,1,4,3,2)
- operation_3_operation_4: T(0,0,8,0,0,0)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,1,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,1,2,3)
- operation_1_operation_2: V(True)
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,16,0,0) — applied
- Applied: operation_4: V(True) — applied
- Applied: operation_3_operation_4: I(0,5,1,4,3,2) — applied
- Applied: operation_3_operation_4: T(0,0,8,0,0,0) — applied
- Applied: operation_3_operation_4: V(False) — fallback
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,1,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,1,2,3) — applied
- Applied: operation_1_operation_2: V(True) — applied
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/resnet50_block_405/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/resnet50_block_405/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/resnet50_block_405/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/resnet50_block_405/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/resnet50_block_405/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/resnet50_block_405/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/resnext50_block_3.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,16,4,0)
- operation_4: T(0,0,1,0)
- operation_4: NT()
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: T(0,0,1,0)
- operation_3_operation_4: T(0,0,0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,5,6,4,3,2,1)
- operation_2: TPF(operation_1;0,0,0,32,2,8,2)
- operation_2: T(0,0,0,0,0,1,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,5,1,4,3,2)
- operation_1_operation_2: T(0,0,8,0,0,1)
- operation_1_operation_2: V(True)
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,16,4,0) — applied
- Applied: operation_4: T(0,0,1,0) — applied
- Applied: operation_4: NT() — applied
- Applied: operation_3_operation_4: I(0,1,2,3) — applied
- Applied: operation_3_operation_4: T(0,0,1,0) — applied
- Applied: operation_3_operation_4: T(0,0,0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,5,6,4,3,2,1) — applied
- Applied: operation_2: TPF(operation_1;0,0,0,32,2,8,2) — applied
- Applied: operation_2: T(0,0,0,0,0,1,0) — applied
- Applied: operation_2: V(False) — fallback
- Applied: operation_1_operation_2: I(0,5,1,4,3,2) — applied
- Applied: operation_1_operation_2: T(0,0,8,0,0,1) — applied
- Applied: operation_1_operation_2: V(False) — fallback
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/resnext50_block_3/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/resnext50_block_3/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/resnext50_block_3/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/resnext50_block_3/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/resnext50_block_3/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/resnext50_block_3/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/resnext50_block_5.mlir</summary>

- operation_4: I(0,1,2,3)
- operation_4: TPF(operation_3;0,16,4,0)
- operation_4: T(0,0,1,0)
- operation_4: NT()
- operation_3_operation_4: I(0,1,2,3)
- operation_3_operation_4: T(0,0,1,0)
- operation_3_operation_4: T(0,0,0,0)
- operation_3_operation_4: NT()
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,4,0)
- operation_2: T(0,0,1,0)
- operation_2: NT()
- operation_1_operation_2: I(0,5,6,4,3,2,1)
- operation_1_operation_2: T(0,0,0,32,4,1,0)
- operation_1_operation_2: T(0,0,0,0,2,0,0)
- operation_1_operation_2: NT()
- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(0,1,2,1,2,4)
- operation_0: V(True)

- Applied: operation_4: I(0,1,2,3) — applied
- Applied: operation_4: TPF(operation_3;0,16,4,0) — applied
- Applied: operation_4: T(0,0,1,0) — applied
- Applied: operation_4: NT() — applied
- Applied: operation_3_operation_4: I(0,1,2,3) — applied
- Applied: operation_3_operation_4: T(0,0,1,0) — applied
- Applied: operation_3_operation_4: T(0,0,0,0) — applied
- Applied: operation_3_operation_4: NT() — applied
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,4,0) — applied
- Applied: operation_2: T(0,0,1,0) — applied
- Applied: operation_2: NT() — applied
- Applied: operation_1_operation_2: I(0,5,6,4,3,2,1) — applied
- Applied: operation_1_operation_2: T(0,0,0,32,4,1,0) — applied
- Applied: operation_1_operation_2: T(0,0,0,0,2,0,0) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(0,1,2,1,2,4) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/ops_and_blocks/resnext50_block_5/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/resnext50_block_5/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/resnext50_block_5/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/resnext50_block_5/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/resnext50_block_5/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/resnext50_block_5/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/vgg16_block_0.mlir</summary>

- operation_4: I(0,5,1,4,3,2)
- operation_4: TPF(operation_3;0,0,32,0,1,0)
- operation_4: V(True)
- operation_3_operation_4: I(0,5,1,4,3,2)
- operation_3_operation_4: T(0,0,8,0,0,1)
- operation_3_operation_4: V(True)
- operation_2: I(0,1,2,3)
- operation_2: TPF(operation_1;0,16,2,0)
- operation_2: V(True)
- operation_1_operation_2: I(0,5,6,4,3,2,1)
- operation_1_operation_2: T(0,0,1,32,2,1,0)
- operation_1_operation_2: T(0,0,0,0,0,0,0)
- operation_1_operation_2: NT()
- operation_0: I(0,1,2,3)
- operation_0: T(0,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_4: I(0,5,1,4,3,2) — applied
- Applied: operation_4: TPF(operation_3;0,0,32,0,1,0) — applied
- Applied: operation_4: V(False) — fallback
- Applied: operation_3_operation_4: I(0,5,1,4,3,2) — applied
- Applied: operation_3_operation_4: T(0,0,8,0,0,1) — applied
- Applied: operation_3_operation_4: V(False) — fallback
- Applied: operation_2: I(0,1,2,3) — applied
- Applied: operation_2: TPF(operation_1;0,16,2,0) — applied
- Applied: operation_2: V(True) — applied
- Applied: operation_1_operation_2: I(0,5,6,4,3,2,1) — applied
- Applied: operation_1_operation_2: T(0,0,1,32,2,1,0) — applied
- Applied: operation_1_operation_2: T(0,0,0,0,0,0,0) — applied
- Applied: operation_1_operation_2: NT() — applied
- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/vgg16_block_0/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/vgg16_block_0/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/vgg16_block_0/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/vgg16_block_0/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/vgg16_block_0/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/vgg16_block_0/methods/mlir_rl/scheduled.mlir)

</details>
