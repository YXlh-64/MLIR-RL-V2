# Generated V5 schedules

Planned choices are followed by actual application outcomes. Pointer decisions remain in schedule.json. Inspect result.json for failures/timeouts.

<details>
<summary>mlir_rl_v1_paper/add_112_15_15_15.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(8,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(8,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/add_112_15_15_15/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/add_112_15_15_15/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/add_112_15_15_15/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/add_112_15_15_15/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/add_112_15_15_15/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/add_112_15_15_15/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/add_28_15_112_7.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/add_28_15_112_7/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/add_28_15_112_7/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/add_28_15_112_7/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/add_28_15_112_7/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/add_28_15_112_7/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/add_28_15_112_7/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/add_56_7_15_120.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(8,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(8,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/add_56_7_15_120/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/add_56_7_15_120/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/add_56_7_15_120/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/add_56_7_15_120/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/add_56_7_15_120/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/add_56_7_15_120/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/add_7_7_224_112.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/add_7_7_224_112/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/add_7_7_224_112/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/add_7_7_224_112/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/add_7_7_224_112/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/add_7_7_224_112/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/add_7_7_224_112/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/conv_2d_nchw_fchw_128_48_7_7_384_3_3_3_3.mlir</summary>

- operation_1: I(0,1,2,3)
- operation_1: TPF(operation_0;0,16,1,0)
- operation_1: T(8,0,0,0)
- operation_1: NT()
- operation_0_operation_1: I(0,1,2)
- operation_0_operation_1: T(8,0,0)
- operation_0_operation_1: T(0,0,0)
- operation_0_operation_1: NT()

- Applied: operation_1: I(0,1,2,3) — applied
- Applied: operation_1: TPF(operation_0;0,16,1,0) — applied
- Applied: operation_1: T(8,0,0,0) — applied
- Applied: operation_1: NT() — applied
- Applied: operation_0_operation_1: I(0,1,2) — applied
- Applied: operation_0_operation_1: T(8,0,0) — applied
- Applied: operation_0_operation_1: T(0,0,0) — applied
- Applied: operation_0_operation_1: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/conv_2d_nchw_fchw_128_48_7_7_384_3_3_3_3/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/conv_2d_nchw_fchw_128_48_7_7_384_3_3_3_3/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/conv_2d_nchw_fchw_128_48_7_7_384_3_3_3_3/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/conv_2d_nchw_fchw_128_48_7_7_384_3_3_3_3/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/conv_2d_nchw_fchw_128_48_7_7_384_3_3_3_3/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/conv_2d_nchw_fchw_128_48_7_7_384_3_3_3_3/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/matmul_1536_256_128.mlir</summary>

- operation_0: I(0,1,2)
- operation_0: T(8,0,8)
- operation_0: T(0,0,1)
- operation_0: NT()

- Applied: operation_0: I(0,1,2) — applied
- Applied: operation_0: T(8,0,8) — applied
- Applied: operation_0: T(0,0,1) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/matmul_1536_256_128/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/matmul_1536_256_128/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/matmul_1536_256_128/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/matmul_1536_256_128/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/matmul_1536_256_128/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/matmul_1536_256_128/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/matmul_256_1536_512.mlir</summary>

- operation_0: I(0,1,2)
- operation_0: T(8,0,8)
- operation_0: T(0,0,1)
- operation_0: NT()

- Applied: operation_0: I(0,1,2) — applied
- Applied: operation_0: T(8,0,8) — applied
- Applied: operation_0: T(0,0,1) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/matmul_256_1536_512/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/matmul_256_1536_512/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/matmul_256_1536_512/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/matmul_256_1536_512/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/matmul_256_1536_512/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/matmul_256_1536_512/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/pooling_nchw_max_128_96_15_15_7_5_5.mlir</summary>

- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(16,1,2,1,0,1)
- operation_0: V(True)

- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(16,1,2,1,0,1) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/mlir_rl_v1_paper/pooling_nchw_max_128_96_15_15_7_5_5/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/pooling_nchw_max_128_96_15_15_7_5_5/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_128_96_15_15_7_5_5/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_128_96_15_15_7_5_5/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_128_96_15_15_7_5_5/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/pooling_nchw_max_128_96_15_15_7_5_5/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/pooling_nchw_max_256_32_7_7_1_4_4.mlir</summary>

- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(16,0,2,0,2,2)
- operation_0: V(True)

- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(16,0,2,0,2,2) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_32_7_7_1_4_4/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_32_7_7_1_4_4/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_32_7_7_1_4_4/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_32_7_7_1_4_4/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_32_7_7_1_4_4/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_32_7_7_1_4_4/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/pooling_nchw_max_256_96_7_7_1_4_4.mlir</summary>

- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(16,0,2,0,2,2)
- operation_0: V(True)

- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(16,0,2,0,2,2) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_96_7_7_1_4_4/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_96_7_7_1_4_4/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_96_7_7_1_4_4/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_96_7_7_1_4_4/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_96_7_7_1_4_4/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/pooling_nchw_max_256_96_7_7_1_4_4/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/relu_128_256.mlir</summary>

- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/relu_128_256/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/relu_128_256/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/relu_128_256/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/relu_128_256/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/relu_128_256/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/relu_128_256/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>mlir_rl_v1_paper/relu_256_256.mlir</summary>

- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/mlir_rl_v1_paper/relu_256_256/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/mlir_rl_v1_paper/relu_256_256/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/mlir_rl_v1_paper/relu_256_256/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/mlir_rl_v1_paper/relu_256_256/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/mlir_rl_v1_paper/relu_256_256/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/mlir_rl_v1_paper/relu_256_256/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/bert_batch_matmul_1.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/bert_batch_matmul_1/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/bert_batch_matmul_1/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/bert_batch_matmul_1/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/bert_batch_matmul_1/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/bert_batch_matmul_1/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/bert_batch_matmul_1/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/bert_batch_matmul_2.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/bert_batch_matmul_2/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/bert_batch_matmul_2/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/bert_batch_matmul_2/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/bert_batch_matmul_2/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/bert_batch_matmul_2/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/bert_batch_matmul_2/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/conv_2d_nchw_fchw_128_48_7_7_48_3_3_5_5.mlir</summary>

- operation_1: I(0,1,2,3)
- operation_1: TPF(operation_0;0,16,1,0)
- operation_1: T(8,0,0,0)
- operation_1: NT()
- operation_0_operation_1: I(0,1,2)
- operation_0_operation_1: T(8,0,0)
- operation_0_operation_1: T(0,0,0)
- operation_0_operation_1: NT()

- Applied: operation_1: I(0,1,2,3) — applied
- Applied: operation_1: TPF(operation_0;0,16,1,0) — applied
- Applied: operation_1: T(8,0,0,0) — applied
- Applied: operation_1: NT() — applied
- Applied: operation_0_operation_1: I(0,1,2) — applied
- Applied: operation_0_operation_1: T(8,0,0) — applied
- Applied: operation_0_operation_1: T(0,0,0) — applied
- Applied: operation_0_operation_1: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/conv_2d_nchw_fchw_128_48_7_7_48_3_3_5_5/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/conv_2d_nchw_fchw_128_48_7_7_48_3_3_5_5/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_128_48_7_7_48_3_3_5_5/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_128_48_7_7_48_3_3_5_5/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_128_48_7_7_48_3_3_5_5/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/conv_2d_nchw_fchw_128_48_7_7_48_3_3_5_5/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/conv_2d_nchw_fchw_256_256_7_7_48_1_1_4_4.mlir</summary>

- operation_1: I(0,1,2,3)
- operation_1: TPF(operation_0;0,16,4,32)
- operation_1: T(8,0,1,0)
- operation_1: NT()
- operation_0_operation_1: I(0,1,2)
- operation_0_operation_1: T(8,0,1)
- operation_0_operation_1: T(0,0,0)
- operation_0_operation_1: NT()

- Applied: operation_1: I(0,1,2,3) — applied
- Applied: operation_1: TPF(operation_0;0,16,4,32) — applied
- Applied: operation_1: T(8,0,1,0) — applied
- Applied: operation_1: NT() — applied
- Applied: operation_0_operation_1: I(0,1,2) — applied
- Applied: operation_0_operation_1: T(8,0,1) — applied
- Applied: operation_0_operation_1: T(0,0,0) — applied
- Applied: operation_0_operation_1: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_256_7_7_48_1_1_4_4/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_256_7_7_48_1_1_4_4/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_256_7_7_48_1_1_4_4/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_256_7_7_48_1_1_4_4/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_256_7_7_48_1_1_4_4/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_256_7_7_48_1_1_4_4/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/conv_2d_nchw_fchw_256_48_7_7_64_1_1_4_4.mlir</summary>

- operation_1: I(0,1,2,3)
- operation_1: TPF(operation_0;0,16,4,0)
- operation_1: T(8,0,1,0)
- operation_1: NT()
- operation_0_operation_1: I(0,1,2)
- operation_0_operation_1: T(8,0,1)
- operation_0_operation_1: V(True)

- Applied: operation_1: I(0,1,2,3) — applied
- Applied: operation_1: TPF(operation_0;0,16,4,0) — applied
- Applied: operation_1: T(8,0,1,0) — applied
- Applied: operation_1: NT() — applied
- Applied: operation_0_operation_1: I(0,1,2) — applied
- Applied: operation_0_operation_1: T(8,0,1) — applied
- Applied: operation_0_operation_1: V(False) — fallback

[Raw decisions](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_48_7_7_64_1_1_4_4/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_48_7_7_64_1_1_4_4/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_48_7_7_64_1_1_4_4/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_48_7_7_64_1_1_4_4/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_48_7_7_64_1_1_4_4/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/conv_2d_nchw_fchw_256_48_7_7_64_1_1_4_4/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/matmul_1536_256_1024.mlir</summary>

- operation_0: I(0,1,2)
- operation_0: T(8,0,8)
- operation_0: T(0,0,1)
- operation_0: NT()

- Applied: operation_0: I(0,1,2) — applied
- Applied: operation_0: T(8,0,8) — applied
- Applied: operation_0: T(0,0,1) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/matmul_1536_256_1024/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/matmul_1536_256_1024/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/matmul_1536_256_1024/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/matmul_1536_256_1024/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/matmul_1536_256_1024/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/matmul_1536_256_1024/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/matmul_512_256_1024.mlir</summary>

- operation_0: I(0,1,2)
- operation_0: T(8,0,8)
- operation_0: T(0,0,1)
- operation_0: NT()

- Applied: operation_0: I(0,1,2) — applied
- Applied: operation_0: T(8,0,8) — applied
- Applied: operation_0: T(0,0,1) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/matmul_512_256_1024/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/matmul_512_256_1024/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/matmul_512_256_1024/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/matmul_512_256_1024/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/matmul_512_256_1024/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/matmul_512_256_1024/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/pooling_nchw_max_128_48_7_7_3_3_3.mlir</summary>

- operation_0: I(0,5,1,4,3,2)
- operation_0: TP(16,1,2,1,0,1)
- operation_0: V(True)

- Applied: operation_0: I(0,5,1,4,3,2) — applied
- Applied: operation_0: TP(16,1,2,1,0,1) — applied
- Applied: operation_0: V(False) — fallback

[Raw decisions](artifacts/ops_and_blocks/pooling_nchw_max_128_48_7_7_3_3_3/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/pooling_nchw_max_128_48_7_7_3_3_3/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/pooling_nchw_max_128_48_7_7_3_3_3/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/pooling_nchw_max_128_48_7_7_3_3_3/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/pooling_nchw_max_128_48_7_7_3_3_3/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/pooling_nchw_max_128_48_7_7_3_3_3/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/relu_128_3072.mlir</summary>

- operation_0: I(0,1)
- operation_0: T(8,0)
- operation_0: T(0,0)
- operation_0: NT()

- Applied: operation_0: I(0,1) — applied
- Applied: operation_0: T(8,0) — applied
- Applied: operation_0: T(0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/relu_128_3072/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/relu_128_3072/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/relu_128_3072/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/relu_128_3072/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/relu_128_3072/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/relu_128_3072/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/relu_256_32_15_15.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(8,0,1,0)
- operation_0: T(0,0,0,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(8,0,1,0) — applied
- Applied: operation_0: T(0,0,0,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/relu_256_32_15_15/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/relu_256_32_15_15/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/relu_256_32_15_15/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/relu_256_32_15_15/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/relu_256_32_15_15/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/relu_256_32_15_15/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/t5_batch_matmul_1.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/t5_batch_matmul_1/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/t5_batch_matmul_1/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/t5_batch_matmul_1/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/t5_batch_matmul_1/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/t5_batch_matmul_1/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/t5_batch_matmul_1/methods/mlir_rl/scheduled.mlir)

</details>

<details>
<summary>ops_and_blocks/t5_batch_matmul_3.mlir</summary>

- operation_0: I(0,1,2,3)
- operation_0: T(0,0,8,0)
- operation_0: T(0,0,1,0)
- operation_0: NT()

- Applied: operation_0: I(0,1,2,3) — applied
- Applied: operation_0: T(0,0,8,0) — applied
- Applied: operation_0: T(0,0,1,0) — applied
- Applied: operation_0: NT() — applied

[Raw decisions](artifacts/ops_and_blocks/t5_batch_matmul_3/methods/mlir_rl/schedule.json) · [Applied actions](artifacts/ops_and_blocks/t5_batch_matmul_3/methods/mlir_rl/applied_actions.json) · [dependency_graph.json](artifacts/ops_and_blocks/t5_batch_matmul_3/methods/mlir_rl/dependency_graph.json) · [fusion_report.json](artifacts/ops_and_blocks/t5_batch_matmul_3/methods/mlir_rl/fusion_report.json) · [schedule_ir_analysis.json](artifacts/ops_and_blocks/t5_batch_matmul_3/methods/mlir_rl/schedule_ir_analysis.json) · [Applied MLIR](artifacts/ops_and_blocks/t5_batch_matmul_3/methods/mlir_rl/scheduled.mlir)

</details>
